module.exports = { 
    mysqlHost: "3.6.50.120",
    // mysqlHost: "localhost",
      user: "esp",
      password: 'E@s@f~@esp',
      database: "praticeData",
      mysqlPort: 3306,
      JWT_SECRET_KEY: 'ly27lg35kci8Rt543DTGgbod4',
      SESSION_EXPIRES_IN: '24h',
      imageUrl:'',
      // mailUrl : 'https://espsofttech.in/cryptox/',
      mailUrl : 'http://localhost:8000/',
  }