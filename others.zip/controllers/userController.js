const userModel = require("../models/userModel")



exports.register = async(req, res)=>{
     try{
         let data = req.body
         let insert = await userModel.insertDetails(data)
         if(insert){
             return res.status(200).send({success: true , msg :"success"})
         }else{
            return res.status(200).send({success: true , msg :"wronng"})
         }
     }catch(err){
            return res.status(200).send({success:false , Error:err.message})
     }
}