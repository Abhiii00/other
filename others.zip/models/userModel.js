const config = require("../config");
// require("dotenv").config();
const mysql = require("mysql2");
const pool = mysql.createPool({
  host: config.mysqlHost,
  user: config.user,
  password: process.env.DB_PASS || config.password,
  database: config.database,
  port: config.mysqlPort,
});
const promisePool = pool.promise();

class userModel {

 insertDetails = async (data) => {
    let sql = `insert into loginUser (name, email, password)values ('${data.name}','${data.email}', '${data.password}')`;
    const [result, fields] = await promisePool.query(sql);
    console.log(sql , result)
    return result;
  };
}
  
  module.exports = new userModel();